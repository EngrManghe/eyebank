from django.apps import AppConfig


class DonorAssessmentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'donor_assessment'
